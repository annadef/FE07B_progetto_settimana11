import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';
import { Articolo } from '../models/product';
import * as Servizi from '../products.service';

@Component({
  template: `
    <div class="card bg-light">
      <div *ngIf="articolo" class="card-body rounded text-center">
        <h5 class="card-title">{{ articolo.name }}</h5>
        <p class="card-text">
          {{ articolo.description }} <br />
          {{ articolo.price | currency: 'EUR' }}
        </p>
        <button type="button" class="btn btn-outline-danger m-2" (click)="aggiungi()">
          Aggiungi al carrello
        </button>
        <button type="button" class="btn btn-outline-danger m-2" [routerLink]="['/']">
          Torna al negozio
        </button>
      </div>
    </div>
  `,
  styles: [
    `
      .card {
        max-width: 800px;
        height: auto;
        border-radius: 50px;
        margin: auto;
        margin-top: 50px;
      }
    `,
  ],
})
export class ProductCardPage implements OnInit {
  articolo!: Articolo;
  sub!: Subscription;

  constructor(private router: ActivatedRoute) {}

  ngOnInit(): void {
    this.sub = this.router.params.subscribe((params: Params) => {
      this.articolo = <Articolo>params;
      console.log(this.articolo);
      console.log(params);
    });
  }

  aggiungi() {
    Servizi.aggiungiAlCarrello(this.articolo);
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
